.. _qualification:

Find My Qualification
#####################

The Find My Qualification sample is a :ref:`simple` sample with the FMN stack run in the qualification mode.

The qualification mode exposes an additional Bluetooth characteristic that is used to send test commands.
You can use this sample to execute tests from the Find My Certification Assistant (FMCA) iOS application.

For more documentation, on the non-qualification part of the application, refer to the :ref:`simple` sample.
