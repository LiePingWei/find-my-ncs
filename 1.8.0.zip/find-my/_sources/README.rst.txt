Apple Find My support for nRF Connect SDK
#########################################

The nRF Connect SDK, together with this Find My add-on and nRF52 SoCs, provide a single-chip Bluetooth Low Energy accessory solution that fulfills the requirements defined by the MFi program for the Find My Network.

Documentation
*************

Find My documentation at:

* Latest: https://github.com/nrfconnect/sdk-find-my/raw/doc_artifacts/latest.zip
* All versions: https://github.com/nrfconnect/sdk-find-my/tree/doc_artifacts
